#!/usr/bin/env bash
make clean build

make run ARGS="-p TFpFX"