Performing RGB to Grayscale on Image Data Assignment
>need to be fixed
