Introduction to Parallel Programming with CUDA\
[certificate link](https://www.coursera.org/account/accomplishments/certificate/J79AFXDDP7NC)
