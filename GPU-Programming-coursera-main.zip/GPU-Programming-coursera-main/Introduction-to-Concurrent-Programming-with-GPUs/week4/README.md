Integrated versus Dedicated GPUs
