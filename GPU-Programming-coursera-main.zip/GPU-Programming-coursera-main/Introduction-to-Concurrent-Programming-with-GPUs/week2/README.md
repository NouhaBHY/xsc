About python thread library: https://starcandytree.tistory.com/42
