Update assignment.cpp, the variable USERNAME should be your username.\
Update or create the .user file to include only one line with the username from above.
