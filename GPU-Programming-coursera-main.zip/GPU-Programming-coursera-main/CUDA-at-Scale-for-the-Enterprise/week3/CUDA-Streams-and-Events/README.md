U​pdate the scaffolding code to execute a number of CUDA stream/event-based synchronous and asynchronous computational scenarios. There is extensive commenting for you to follow to implement the various scenarios. As a note do not modify the existing print/output to standard IO. Doing so could cause your submission to fail or lower your grade. Perform the following steps to 

1. C​lick the Build button.

2. C​lick the Run button.

3. C​lick the Submit Assignment button.