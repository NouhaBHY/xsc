week3
